
let ghosts = [], pumpkins = [], score = 0, lives = 3, timeLeft = 30;
let started = false, ended = false, startTime = 0, lastGhost = 0, lastPumpkin = 0;
function setup() {   createCanvas(800, 500);
  textFont("Georgia");
}
function draw() {   background(20, 18, 40);
  drawBackground();
  if (!started) {
    if (ended) drawGameOver();
    else drawStart();
    return;
  }
  updateGame();
  drawTargets();
  drawHUD();
}
function drawBackground() {
  noStroke();
  fill(255, 230, 160); circle(650, 90, 75);
  fill(30, 35, 50);
  triangle(0, 410, 180, 250, 350, 410);
  triangle(350, 410, 570, 220, 800, 410);
  fill(25, 55, 35); rect(0, 410, 800, 90);
  fill(35, 25, 40); rect(330, 280, 140, 130);
  triangle(310, 280, 400, 210, 490, 280);
  fill(255, 130, 20);
  rect(355, 310, 30, 40); rect(415, 310, 30, 40);
}
function drawStart() {   textAlign(CENTER); fill(255, 140, 30); textSize(48);
  text("PUMPKIN PANIC", 400, 160);
  fill(255); textSize(21);
  text("Click ghosts. Avoid pumpkins!", 400, 230);
  text("Click to start", 400, 340);
}
function startGame() {   ghosts = []; pumpkins = []; score = 0; lives = 3;
  started = true; ended = false; startTime = millis();
  lastGhost = millis(); lastPumpkin = millis();
}
function updateGame() {
  timeLeft = max(0, 30 - floor((millis() - startTime) / 1000));
  if (timeLeft <= 0 || lives <= 0) {
    started = false; ended = true; return;
  }
  if (millis() - lastGhost >= 1000) {
    spawnGhost(); lastGhost = millis();
  }
  if (millis() - lastPumpkin >= 1500) {
    spawnPumpkin(); lastPumpkin = millis();
  }
  for (let g of ghosts) {
    g.x += g.speed;
    if (g.x > 820) g.x = -20;
  }
}
function spawnGhost() {   ghosts.push({x: random(30, 770), y: random(120, 390), speed: random(1, 2.5), size: 40});
}
function spawnPumpkin() {   pumpkins.push({x: random(30, 770), y: random(120, 390), size: 40});
}
function drawTargets() {
  for (let g of ghosts) {
    fill(230, 245, 255); ellipse(g.x, g.y, g.size, g.size);
    rect(g.x - 20, g.y, 40, 20); fill(20);
    circle(g.x - 8, g.y - 5, 6); circle(g.x + 8, g.y - 5, 6);
  }
  for (let p of pumpkins) {
    fill(245, 100, 0); ellipse(p.x, p.y, p.size, p.size * 0.8);
    fill(20);
    triangle(p.x - 12, p.y - 5, p.x - 4, p.y - 15, p.x - 2, p.y);
    triangle(p.x + 12, p.y - 5, p.x + 4, p.y - 15, p.x + 2, p.y);
    fill(30, 120, 40); rect(p.x - 3, p.y - 25, 6, 10);
  }
}
function mousePressed() {
  if (!started) { startGame(); return; }
  for (let i = ghosts.length - 1; i >= 0; i--) {
    let g = ghosts[i];
    if (dist(mouseX, mouseY, g.x, g.y) < 25) {
      score++; ghosts.splice(i, 1); return;
    }
  }
  for (let i = pumpkins.length - 1; i >= 0; i--) {
    let p = pumpkins[i];
    if (dist(mouseX, mouseY, p.x, p.y) < 25) {
      lives--; pumpkins.splice(i, 1); return;
    }
  }
}
function drawHUD() {
  fill(255); textSize(20); textAlign(LEFT);
  text("Score: " + score, 25, 35);
  text("Lives: " + lives, 25, 65);
  textAlign(RIGHT); text("Time: " + timeLeft, 770, 35);
}
function drawGameOver() {
  textAlign(CENTER); fill(255, 130, 20); textSize(48);
  text("GAME OVER", 400, 190);
  fill(255); textSize(25);
  text("Final score: " + score, 400, 250);
  textSize(20); text("Click to play again", 400, 330);
}

